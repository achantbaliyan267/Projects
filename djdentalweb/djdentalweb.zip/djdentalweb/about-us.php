<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "./components/header.php" ?>

        <style>
            .carousel-container {
            overflow-x: hidden;
            overflow-y: visible;
            position: relative;
            width: 100%;
            }

            .carousel-track {
              display: flex;
              gap: 1.5rem;
              width: max-content;
              animation: scroll 25s linear infinite;
              will-change: transform;
            }

            .carousel-container:hover .carousel-track {
              animation-play-state: paused;
              cursor: pointer;
            }

            .card {
              flex: 0 0 auto;
              min-width: 220px;
              max-width: 240px;
              border: none;
              background-color: #ffe3d8;
              border-radius: 1rem;
            }

            .card img {
              width: 100%;
              height: auto;
              border-radius: 1rem;
            }

            @keyframes scroll {
              0% { transform: translateX(0); }
              100% {
                transform: translateX(-50%);
              }
            }

            @media (max-width: 768px) {
              .card {
                min-width: 180px;
              }
            }

            @media (max-width: 500px) {
              .card {
                min-width: 150px;
              }
            }

            .gradient-text {
                background: linear-gradient(90deg, rgb(225 45 35), #ff8419, rgb(225 45 35));
                background-size: 200% auto;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                animation: gradientMove 3s linear infinite;
                font-weight: bold;
            }

            .service-card-image {
                position: relative;
                overflow: hidden;
                border-radius: 20px; /* same as ::before */
            }

            .service-card-image img {
              width: 100%;
              height: auto;
              display: block;
              border-radius: 20px;
            }

            .service-card-image::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(to bottom, #f50909c7, #ff841963 100%);
                border-radius: 20px;
                z-index: 0;
            }
        </style>
</head>

<body>
    <?php include "./components/navbar.php" ?>
    <header>
        <div class="container my-5 pb-5">
          <!-- ======================= Hero Header Section ======================= -->
          <header class="hero-section d-flex align-items-center rounded-4" style="background-image: url(./media/herosectionbanner.webp);
    object-fit: cover;
    min-height: 400px;
    background-repeat: no-repeat;
    background-size: cover;">
            <div class="container position-relative">
              <div class="row">
                <!-- Text Content Column -->
               <div class="col-lg-7 col-md-8 p-4" >
                <h1 class="display-4 fw-bold text-white mb-3">
                    Shaping Bright Futures<br>in <span class="gradient-text">Dental Science</span>
                </h1>
                <p class="lead text-white mb-4">
                    At DJ Dental College, we combine advanced learning, clinical excellence, and compassionate care to prepare skilled dental professionals who make a difference.
                </p>
                <div class="rounded-4 px-4 pt-3 pb-4 mt-5 mt-lg-0" style="margin-left: -27px; margin-bottom: -135px; width: fit-content; background-color: #fffdfa;">
                    <a href="#" class="btn btn-dark rounded-pill p-2 mt-2 mt-lg-0">Explore More About Us</a>
                </div>
                </div>


              </div>
            </div>
          </header>
        </div>
    </header>

        <!-- About US -->
        <div class="container my-5 bg-white rounded-4 shadow">
            <div class="row">
                <div class="col-md-8 p-4">
                    <h4 class="display-5 fw-semibold"><span class="gradient-text">About</span> Us</h4>
                    <p class="mt-4">DJ College of Dental Sciences and Research was established in 1999 under the founding guidance of founder and chairman Ajit Singh Jassar. We were one of the first five private colleges in the state of Uttar Pradesh.
                        <br>
                        <br> Over the last decade, DJCDSR, has worked to achieve excellence in the field of dental research, and now comprises the finest faculty and state-of-the-art equipment for groundbreaking scientific innovation. This is reflected in
                        the numerous laurels that students of our college have amassed over the years in both national and international conferences and competitions.</p>
                </div>
                <div class="col-md-4 mt-4 p-4">
                    <div class="d-grid gap-3">
                        <div class="d-flex gap-3">
                            <div class="flex-fill text-center rounded-4 px-2 py-3 shadow-sm" style="background-color: #ffe3d8;">
                                <p class="fs-2 fw-semibold mb-0">800+</p>
                                <p class="mb-0">Research Papers</p>
                            </div>
                            <div class="flex-fill text-center rounded-4 px-2 py-3 shadow-sm" style="background-color: #ffe3d8;">
                                <p class="fs-2 fw-semibold mb-0">75+</p>
                                <p class="mb-0">Acres Campus</p>
                            </div>
                        </div>

                        <div class="d-flex gap-3">
                            <div class="flex-fill text-center rounded-4 px-2 py-3 shadow-sm" style="background-color: #ffe3d8;">
                                <p class="fs-2 fw-semibold mb-0">110+</p>
                                <p class="mb-0">Patents Done</p>
                            </div>
                            <div class="flex-fill text-center rounded-4 px-2 py-3 shadow-sm" style="background-color: #ffe3d8;">
                                <p class="fs-2 fw-semibold mb-0">25+</p>
                                <p class="mb-0">Years Legacy</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>


        <!-- Carousel -->
        <div class="container rounded-4 p-4 my-4">
            <div class="d-flex justify-content-between align-items-center">
                <p class="display-5 fw-semibold m-0"><span class="gradient-text">Services</span> we provide</p>
                <!-- <div>
                    <button id="prevBtn" class="rounded-circle py-1 px-2">
                        <i class="bi bi-arrow-left"></i>
                    </button>
                    <button id="nextBtn" class="rounded-circle py-1 px-2 ms-2">
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </div> -->
            </div>

            <div class="carousel-container mt-4" id="carousel">
                <div class="carousel-track" id="carouselTrack">
                    <!-- Duplicate cards for seamless loop -->
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 1</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 2</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 3</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 4</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 5</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 6</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 7</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 8</p>
                        </div>
                    </div>

                    <!-- Duplicate again for infinite loop -->
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 1</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 2</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 3</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 4</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 5</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 6</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 7</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="service-card-image">
                            <img src="./images/BBA-MUJ.png">
                        </div>
                        <div class="card-body">
                            <p>Service 8</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Competency -->
        <div class="container my-4">
            <div class="row">
                <div class="col-md-4 mt-4 px-4 pb-4">
                    <img src="./images/bg.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-8 mt-4 p-4 bg-white rounded-4 shadow" style="height: fit-content;">
                    <h4 class="display-6"><span class="gradient-text">COMPETENCY</span> STATEMENTS</h4>
                    <div class="mt-3"><strong>The institute prepares the student to be :</strong></div>
                    <div class="d-flex gap-2 mt-3">
                        <div class="h-50 rounded-circle px-1 text-white" style="background: linear-gradient(135deg, #ff1200, #ffc107);"><i class="bi bi-check"></i></div>
                        <p>Knowledgeable in biomedical and oro-dental health sciences and evidence based dental clinical care.</p>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="h-50 rounded-circle px-1 text-white" style="background: linear-gradient(135deg, #ff1200, #ffc107);"><i class="bi bi-check"></i></div>
                        <p>A skilled communicator, empathetic health advocate and compassionate healthcare provider.</p>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="h-50 rounded-circle px-1 text-white" style="background: linear-gradient(135deg, #ff1200, #ffc107);"><i class="bi bi-check"></i></div>
                        <p>An ethical professional and an engaged team player</p>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="h-50 rounded-circle px-1 text-white" style="background: linear-gradient(135deg, #ff1200, #ffc107);"><i class="bi bi-check"></i></div>
                        <p>A continuous learner of practice and quality improvement.</p>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="h-50 rounded-circle px-1 text-white" style="background: linear-gradient(135deg, #ff1200, #ffc107);"><i class="bi bi-check"></i></div>
                        <p>An astute healthcare member, understanding its organization and economics of the health care system.</p>
                    </div>
                    <div class="d-flex gap-2">
                        <div class="h-50 rounded-circle px-1 text-white" style="background: linear-gradient(135deg, #ff1200, #ffc107);"><i class="bi bi-check"></i></div>
                        <p>A responsible and upright citizen with leadership qualities.</p>
                    </div>
                </div>
            </div>
        </div>


        <!-- Vision & Mission -->
        <!-- Vision & Mission -->
        <div class="container my-5">
            <h4 class="display-5 gradient-text">Vision & Mission</h4>
            <div class="container bg-white rounded-4 shadow pb-4 px-4 mt-4">

                <div class="row">
                    <div class="col-md-8 vis-img">
                      <img src="./media/about/1.jpg" alt="" class="img-fluid mt-5 h-75 mx-4 rounded-4 mb-4 shadow">
                    </div>
                    <div class="col-md-4 mt-5 vis-txt">
                      <p class="display-6 fw-bold">Vision</p>
                      <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos consequuntur, veritatis animi eaque nisi tempora dolore asperiores quia vel sint optio quae ipsam accusamus, laborum itaque aliquid, qui dolores aliquam.</p>
                    </div>
                </div>

                <div class="row">
                  <div class="col-md-8">
                    <p class="display-6 fw-bold">Mission</p>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum aspernatur cum, voluptate amet sunt ratione soluta ullam voluptas tempore rem nobis. Nostrum ducimus voluptas fugiat nulla provident laborum, facilis deserunt.</p>
                  </div>
                  <div class="col-md-4" style="margin-top: -130px;">
                    <img src="./images/MBA.webp" alt="" class="img-fluid rounded-4 shadow">
                  </div>
                </div>

            </div>
        </div>

        <style>
          /* ✅ Mobile responsiveness only */
          @media (max-width: 992px) {
            .row {
              display: flex;
              flex-direction: column !important;
              align-items: center;
              text-align: center;
            }
        
            .col-md-8, .col-md-4 {
              width: 100% !important;
              margin: 0 !important;
              padding: 0 !important;
            }
        
            /* Fix for second image spacing */
            .col-md-4[style] {
              margin-top: 20px !important;
            }
        
            .img-fluid {
              height: auto !important;
              max-width: 100% !important;
              margin: 10px 0 !important;
            }
        
            p.display-6 {
              margin-top: 20px;
            }
          }

          @media (max-width: 767px) {
            .row {
              display: flex;
              flex-direction: column !important;
              align-items: center;
              text-align: center;
            }
        
            .col-md-8, .col-md-4 {
              width: 100% !important;
              margin: 0 !important;
              padding: 0 !important;
            }
        
            /* Fix for second image spacing */
            .col-md-4[style] {
              margin-top: 20px !important;
            }
        
            .img-fluid {
              height: auto !important;
              max-width: 100% !important;
              margin: 10px 0 !important;
            }
        
            p.display-6 {
              margin-top: 20px;
            }
          }

          @media (max-width: 1398px) {
            .col-md-4[style] {
              margin-top: -70px !important;
            }
          }

          @media (max-width: 1200px) {
            .col-md-4[style] {
              margin-top: -25px !important;
            }
            
            .vis-img {
                margin-left: -30px;
            }
            
            .vis-txt {
                margin-left: 20px;
            }
          }
        </style>


        <!-- Approvals -->
        <div class="container my-5">
            <div class="row">
                <h4 class="display-5 gradient-text">Approval & Affiliation</h4>
                <div class="col-md-8 mt-4 bg-white p-4 rounded-4 shadow">
                    Academic Affiliations: <a href="#" class="text-info text-decoration-none">DJ College of Dental Sciences & Research</a> currently affiliated to Atal Bihari Vajpayee Medical University (ABVMU), Lucknow, Atal Bihari Vajpayee Medical University (ABVMU) is a state collegiate university in Lucknow, Uttar Pradesh (India). It is expected to open in 2020 from a transit campus at Mall Avenue, Lucknow and will give affiliation to all government and private medical, dental, replica paramedical and nursing colleges in the state of Uttar Pradesh. It was established by Uttar Pradesh act no. 42 of 2018
                    <br><br>
                    To be one of the best medical hub for providing comprehensive teaching, training and research to all health care workers.
                    <br><br>
                    To serve the society by providing adequately trained manpower which can cater to the health needs, beginning from prevention to primary care to tertiary care.
                </div>
                <div class="col-md-4">
                    <div class="container rounded-4 shadow bg-white p-4 mt-4">
                        <p class="fw-semibold fs-5">Academic Partners / Collaborations</p>
                        <div id="carouselExample" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2000">
                           <div class="carousel-inner">
  <div class="carousel-item active" style="height: 35vh;">
    <img src="./media/about/academic/lo1.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo2.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo3.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo4.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo5.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo6.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo7.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo8.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
  <div class="carousel-item" style="height: 35vh;">
    <img src="./media/about/academic/lo9.png" class="d-block w-100 img-fluid carousel-img" alt="...">
  </div>
</div>
<style>
    .carousel-img {
  height: 35vh;
  object-fit: scale-down;
  object-position: center;
}

</style>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  



        <?php include "./components/placement.php"?>
        <?php include "./components/footer.php"?>

        <script>
            const track = document.getElementById('carouselTrack'); // your track element
            const container = document.getElementById('carouselContainer'); // wrapper with overflow:hidden
            let pxPerFrame = 0.6; // adjust speed (pixels per frame)
            let tx = 0;

            function animate() {
              tx -= pxPerFrame;
              // when we've scrolled half of the track (because we duplicated content), reset
              const half = track.scrollWidth / 2;
              if (Math.abs(tx) >= half) tx = 0;
              track.style.transform = `translateX(${tx}px)`;
              requestAnimationFrame(animate);
            }

            requestAnimationFrame(animate);

            // optional: pause on hover
            container.addEventListener('mouseenter', () => pxPerFrame = 0);
            container.addEventListener('mouseleave', () => pxPerFrame = 0.6);

        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>