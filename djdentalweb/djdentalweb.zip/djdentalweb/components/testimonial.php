 <style>
    :root {
      --center-offset: 100px;
      --gap1: 15vw;
      --gap2: 27vw;
      --offscreen: 70vw;
    }


    /* Container */
    .vid-container {
      max-width: 100%;
      overflow: hidden;
      margin-left: -100px;
    }

    #carousel {
      height: 420px;
      margin: auto;
      position: relative;
      padding: 20px;
    }

    .carousel-items {
      position: relative;
      width: 100%;
      height: 100%;
      overflow: hidden;
    }

    /* Items */
    .item {
      position: absolute;
      top: 0;
      border-radius: 12px;
      transition: all 0.8s ease;
      overflow: hidden;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
    }

    .item video {
      width: 100%;
      height: 100%;
      object-fit: cover;
      pointer-events: auto !important;
      border-radius: 12px;
      display: block;
    }

    /* Levels */
    .level0 { left: 50%; transform: translateX(-50%) scale(1); width: 240px; height: 350px; z-index: 5; }
    .level1 { left: calc(50% - var(--gap1)); transform: translateX(-50%) scale(0.9); opacity: 0.9; width: 200px; height: 320px; z-index: 4; }
    .level-1 { left: calc(50% + var(--gap1)); transform: translateX(-50%) scale(0.9); opacity: 0.9; width: 200px; height: 320px; z-index: 4; }
    .level2 { left: calc(50% - var(--gap2)); transform: translateX(-50%) scale(0.8); opacity: 0.7; width: 200px; height: 280px; z-index: 3; }
    .level-2 { left: calc(50% + var(--gap2)); transform: translateX(-50%) scale(0.8); opacity: 0.7; width: 200px; height: 280px; z-index: 3; }

    /* Animation classes */
    .left-enter, .right-enter {
      opacity: 0;
      width: 200px;
      height: 280px;
      transform: scale(0.7);
      z-index: 2;
    }

    .left-enter { left: calc(50% - var(--offscreen)); }
    .right-enter { left: calc(50% + var(--offscreen)); }

    .left-enter-active {
      opacity: 1;
      left: calc(50% - var(--gap2));
      transform: translateX(-50%) scale(0.8);
    }
    .right-enter-active {
      opacity: 1;
      left: calc(50% + var(--gap2));
      transform: translateX(-50%) scale(0.8);
    }
    .left-leave-active {
      opacity: 0;
      left: calc(50% + var(--offscreen));
      transform: translateX(-50%) scale(0.7);
    }
    .right-leave-active {
      opacity: 0;
      left: calc(50% - var(--offscreen));
      transform: translateX(-50%) scale(0.7);
    }

    /* Arrows */
    .arrow {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      width: 40px;
      height: 40px;
      background: white !important;
      border-radius: 50%;
      display: flex !important;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 10;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
      transition: all 0.3s ease;
      border: 2px solid white
    }

    .arrow:hover {
      transform: translateY(-50%) scale(1.1);
      background: #f8f9fa !important;
    }

    .arrow-left { left: -20px; }
    .arrow-right { right: -20px; }
    .arrow i { color: #228291; font-size: 1.2rem; }

    /* --- Responsive Fixes --- */
    @media (max-width: 992px) {
      .vid-container { margin-left: 0 !important; overflow-x: hidden; }

      #carousel {
        width: 100% !important;
        height: 420px !important;
      }

      .item {
        left: 50% !important;
        transform: translateX(-50%) scale(1) !important;
        width: 85vw !important;
        height: 380px !important;
      }

      .level0, .level1, .level-1, .level2, .level-2 {
        left: 50% !important;
        transform: translateX(-50%) scale(1) !important;
        opacity: 1 !important;
        width: 85vw !important;
        height: 380px !important;
      }

      .arrow-left { left: 10px !important; }
      .arrow-right { right: 10px !important; }
    }

    @media (max-width: 768px) {
      :root {
        --gap1: 0vw;
        --gap2: 0vw;
        --offscreen: 50vw;
      }

      #carousel {
        /* width: 122% !important; */
        height: 340px !important;
        overflow: hidden !important;
        position: relative;
      }

      .item {
        left: 50% !important;
        transform: translateX(-50%) scale(1) !important;
        opacity: 1 !important;
        z-index: 5 !important;
        width: 80vw !important;
        height: 300px !important;
      }

      .level1, .level-1, .level2, .level-2 {
        display: none !important;
      }
    }
  </style>
  <section class="testimonials">
  <div class="container ">
    <div class="text-center mb-5">
      <h2 class="display-5 fw-bold">
        Students <span class="gradient-text">Point of Views</span>
      </h2>
    </div>

    <div class="row justify-content-center">
      <div class=" position-relative">
        <div id="carousel" class="d-flex align-items-center justify-content-between position-relative">
          <button class="arrow shadow-lg arrow-left btn btn-light rounded-circle position-absolute start-0 translate-middle-y top-50">
            <i class="bi bi-chevron-left fs-4"></i>
          </button>

          <div class="carousel-items w-100 mx-5"></div>

          <button class="arrow shadow-lg arrow-right btn btn-light rounded-circle position-absolute end-0 translate-middle-y top-50">
            <i class="bi bi-chevron-right fs-4"></i>
          </button>
        </div>
      </div>
    </div>
  </div>
</section>


  <script>
  const videos = [
  "https://www.w3schools.com/html/mov_bbb.mp4",
  "https://www.w3schools.com/html/movie.mp4",
  "https://cdn.pixabay.com/video/2021/09/13/89414-611095063_large.mp4",
  "https://cdn.pixabay.com/video/2023/04/26/159868-821064408_large.mp4",
  "https://cdn.pixabay.com/video/2020/09/10/50768-456276944_large.mp4",
  "https://cdn.pixabay.com/video/2021/01/29/65320-509524112_large.mp4"
];


    let currentIndex1 = 0;
    const container1 = document.querySelector('.carousel-items');

    function createItem(src, className) {
      const item = document.createElement('div');
      item.className = `item ${className}`;

      const video = document.createElement('video');
      video.src = src;
      video.controls = true;
      video.playsInline = true;
      video.preload = "metadata";

      video.addEventListener('click', (e) => {
        if (video.paused) video.play().catch(() => {});
        else video.pause();
        e.stopPropagation();
      });

      item.appendChild(video);
      return item;
    }

    function init() {
      container1.innerHTML = '';
      for (let k = 0; k < 5; k++) {
        const level = [2, 1, 0, -1, -2][k];
        const idx = (currentIndex1 + k - 2 + videos.length) % videos.length;
        container1.appendChild(createItem(videos[idx], `level${level}`));
      }
    }

    function next() {
      const children = [...container1.children];
      const leaving = children[0];
      const enteringIdx = (currentIndex1 + 3) % videos.length;
      const entering = createItem(videos[enteringIdx], 'right-enter');
      container1.appendChild(entering);
      entering.offsetHeight;
      entering.classList.add('right-enter-active');

      children[1].className = 'item level2';
      children[2].className = 'item level1';
      children[3].className = 'item level0';
      children[4].className = 'item level-1';
      leaving.classList.add('right-leave-active');

      currentIndex1 = (currentIndex1 + 1) % videos.length;
      setTimeout(() => {
        leaving?.remove();
        entering.className = 'item level-2';
      }, 800);
    }

    function prev() {
      const children = [...container1.children];
      const leaving = children[4];
      const enteringIdx = (currentIndex1 - 2 + videos.length) % videos.length;
      const entering = createItem(videos[enteringIdx], 'left-enter');
      container1.insertBefore(entering, children[0]);
      entering.offsetHeight;
      entering.classList.add('left-enter-active');

      children[0].className = 'item level1';
      children[1].className = 'item level0';
      children[2].className = 'item level-1';
      children[3].className = 'item level-2';
      leaving.classList.add('left-leave-active');

      currentIndex1 = (currentIndex1 - 1 + videos.length) % videos.length;
      setTimeout(() => {
        leaving?.remove();
        entering.className = 'item level2';
      }, 800);
    }

    document.querySelector('.arrow-left').addEventListener('click', prev);
    document.querySelector('.arrow-right').addEventListener('click', next);

    init();
  </script>