<section class="section d-flex align-items-center">
  <div class="overlay"></div>
  <div class="container text-center">
    <h2 class="section-title mb-4 gradient-text " data-aos="fade-up" data-aos-delay="100">
      Placement Opportunities
    </h2>
    <!-- <p class="mb-5 text-warning" data-aos="fade-up" data-aos-delay="200">
      We are proud to be recognized and accredited by leading organizations.
    </p> -->

    <!-- Owl Carousel -->
    <div id="owl-demo" class="owl-carousel owl-theme" data-aos="zoom-in" data-aos-delay="300">
      <div class="item"><img src="./media/about/academic/1.png" alt="1"></div>
      <div class="item"><img src="./media/about/academic/2.png" alt="2"></div>
      <div class="item"><img src="./media/about/academic/3.png" alt="3"></div>
      <div class="item"><img src="./media/about/academic/4.png" alt="4"></div>
      <div class="item"><img src="./media/about/academic/5.png" alt="5"></div>
    </div>
  </div>
</section>

<!-- AOS CSS -->
<link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 1000,
    once: true
  });
</script>

<!-- Owl Carousel CSS & JS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<script>
  $(document).ready(function(){
    $("#owl-demo").owlCarousel({
      items: 4,
      loop: true,
      autoplay: true,
      autoplayTimeout: 2000,
      autoplayHoverPause: true,
      dots: false,
      nav: false,
      responsive:{
        0:{ items:2 },
        768:{ items:3 },
        992:{ items:5 }
      }
    });
  });
</script>

<style>
  /* Parallax Section */
  /* .parallax-section {
    position: relative;
    background: url('./media/internationalacc/bg.jpg') center center / cover no-repeat fixed;
    padding: 80px 0;
    color: #fff;
    z-index: 1;
  } */

  .parallax-section .overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    z-index: -1;
  }

  /* Owl Carousel Items */
  .owl-carousel .item {
    background: rgba(255, 255, 255, 0.9);
    padding: 25px;
    border-radius: 12px;
    text-align: center;
    transition: transform 0.3s, box-shadow 0.3s;
  }

  .owl-carousel .item:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  }

  .owl-carousel .item img {
    max-height: 80px;
    object-fit: contain;
    width: auto;
    margin: 0 auto;
    display: block;
  }
</style>